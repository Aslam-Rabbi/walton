from django.shortcuts import render, HttpResponseRedirect
from .froms import StudentRegistration
from .models import User


# Create your views here.

def index(request):
    if request.method == 'POST':
        fm = StudentRegistration(request.POST)
        if fm.is_valid():
            nd = fm.cleaned_data['id']
            nm = fm.cleaned_data['name']
            ag = fm.cleaned_data['age']
            se = fm.cleaned_data['sex']
            fn = fm.cleaned_data['father_name']
            mn = fm.cleaned_data['mothers_name']
            le = fm.cleaned_data['last_Education']

            reg = User(id=nd, name=nm, age=ag, sex=se, father_name=fn, mothers_name=mn, last_Education=le)
            reg.save()
            fm = StudentRegistration()
    else:
        fm = StudentRegistration()
    stud = User.objects.all()
    return render(request, "index.html", {'form': fm, 'stu': stud})


def update(request):
    books = User.objects.get(pk=id)
    books.title = request.GET['title']
    books.price = request.GET['price']
    books.author = request.GET['author']
    books.save()
    return HttpResponseRedirect('/')
    return render(request, 'templates/update.html')


def edit(request, id):
    Edit = User.objects.get(pk=id)
    context = {
        'Edit': Edit
    }
    return render(request, 'Edit.html', context)


def delete(request, id):
    if request.method == 'POST':
        pi = User.objects.get(pk=id)
        pi.delete()
    return HttpResponseRedirect('/')
